import logo from './logo.svg';
import './App.css';
import Header from './components/Header';
import Footer from './components/Footer';
import NameList from './components/NameList';
import NameTable from './components/NameTable';
import {useState} from 'react'
function App() {
  //let arr=["Revati","Rajan","Atharava","Ashwini"]
  const [arr,setarr]=useState(["Revati","Rajan","Atharava","Ashwini"])
  const addnewname=(name)=>{
    setarr([...arr,name])
   // console.log(arr);

  }
  return (
    <div>
    <Header></Header>
    Search: <input type="text" name="search" id="search"></input><br></br>
    <div className="mydiv">
       <NameList namearr={arr} insertnewName={addnewname}></NameList>
    </div>
    <div className="mydiv">
       <NameTable namearr={arr}></NameTable>
    </div>
    <Footer></Footer>
    </div>
  );
}

export default App;
