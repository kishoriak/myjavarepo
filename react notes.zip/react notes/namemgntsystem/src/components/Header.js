const Header=()=>{
    return(
        <h1 style={{backgroundColor:"blue","color":"white"}}>Name Management System</h1>
    )
}

export const Test=()=>{
    return(
        <h1 style={{backgroundColor:"blue","color":"white"}}>In Testn</h1>
    )
}
export default Header;