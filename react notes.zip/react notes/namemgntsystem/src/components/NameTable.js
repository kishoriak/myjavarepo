import React from 'react'

export default function NameTable(props) {
    console.log("NameTable called")
  return (
    <div>
        <table border='2'>
            {props.namearr.map((nm,index)=><tr key={index}><td>{nm}</td></tr>)}
        </table>
    </div>
  )
}
