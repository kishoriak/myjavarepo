import React,{useState,useEffect} from 'react';


export default function NameForm(props) {
    const [name,setname]=useState("");
    useEffect(()=>{
        console.log(name)
    },[name])
    const handlechange=(event)=>{
          setname(event.target.value)
    }
    const addname=()=>{
        console.log("in nameform add" +name);
        //validate name is not empty
        if(name==="" || name.trim().length==0){
            alert("name cannot be empty");
            return;
        }
        props.addnewname(name);
    }
  return (
    <div>
       <form>
          Name : <input type="text" name="name" id="name"
          value={name}
          onChange={handlechange}></input><br></br>
          <button type="button" id="btn" value="add" onClick={addname}>Add name</button>
          <button type="button" id="btn" value="delete">Delete name</button>
          <button type="button" id="btn" value="update">Update name</button>
       </form>
    </div>
  )
}
