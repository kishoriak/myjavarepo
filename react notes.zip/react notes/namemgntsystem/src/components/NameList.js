import React from 'react'
import NameForm from './NameForm'
export default function NameList(props) {
    console.log("NameList called")
    const insertname=(name)=>{
        console.log("in insertname NameList"+name);
        props.insertnewName(name);

    }
  return (
    <div>
    <ul>
        {props.namearr.map((nm,index,arr)=><li key={index}>{index+1}. {nm}</li>)}
    </ul>
    <NameForm addnewname={insertname}></NameForm>
    </div>
  )
}
