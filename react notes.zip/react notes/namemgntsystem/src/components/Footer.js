import "./Footer.css"
const Footer=()=>{
    return (
        <h4 className="myfooter">&copy; copyrights reserved</h4>
    )
}
export default Footer;