package com.bean.dao;

import com.demo.bean.Account;
import com.demo.exception.WrongPin;

public interface AccountDao {
	public void AcceptDataSavings(String name,int pin,double bal,int cbnum);
	public void AcceptDataCurrent(String name,int pin,double bal);
	public void deposit(int id,double dep) ;
	public Account display(int id) throws UserNotFound;
	public int searchById(int id);
	public void withdraw(int id,double amt,int pin) throws WrongPin;
	
}
