package com.bean.dao;

import com.demo.bean.Account;
import com.demo.bean.Current;
import com.demo.bean.Savings;
import com.demo.exception.WrongPin;

public class AccountDaoImp  implements AccountDao {
//static members
	public static Account[] p;
	public static int cnt;
	static {
		p=new Account[5];
		cnt=0;
		}		
	//accepting data
	public void AcceptDataSavings(String name,int pin,double bal,int cbnum) {
		p[cnt]=new Savings(name,pin,bal,cbnum);
		cnt++;
	}
	public void AcceptDataCurrent(String name,int pin,double bal) {
		p[cnt]=new Current(name,pin,bal);
		cnt++;
	}
	
	
	
	//deposit
	public void deposit(int id,double dep) {
		int sid=searchById(id);
		p[sid].withdraw(dep);
	}
	public Account display(int id) throws UserNotFound {
		int sid=searchById(id);
		if(sid!=-1) {
		return p[sid];
	}
		else {
			throw new UserNotFound("UserNotFound");
		}
	}
	//interest
	public double interest(int id) {
		int sid=searchById(id);
		return p[sid].interest();
	}
public int searchById(int id)  {
		for(int i=0;i<p.length;i++) {
			if(p[i].getid()==id) {
				return i;
			}
	}return -1;
}
//withdraw
public void withdraw(int id,double amt,int pin) throws WrongPin{
	int sid=searchById(id);
	boolean check=p[sid].verifyPin(pin);
	if(check==true) {
	p[sid].withdraw(amt);
	}
	else {
		throw new WrongPin("Wrong Pin");
	}

	
}
}
	  
	
	


