package com.bean.dao;

public class UserNotFound extends Exception{
public UserNotFound(String mesg) {
	super(mesg);
}
}