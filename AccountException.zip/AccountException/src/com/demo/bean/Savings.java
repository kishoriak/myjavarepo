package com.demo.bean;

public class Savings extends Account {
	private int minbal=10000;
	private double irate=0.05;
	private int cbnum;
	//default constructor
	public Savings() {
		minbal=0;
		cbnum=0;
	}
	//parametrized constructor
	public Savings(String name,int pin,double balance, int cbnum) {
		super(name,pin,balance);
	     this.cbnum = cbnum;
	}
	//getter and setter
	public int getCbnum() {
		return cbnum;
	}
	public void setCbnum(int cbnum) {
		this.cbnum = cbnum;
	}
	//interest
	public double interest() {
		double bal=getBalance();
		if(bal>50000)
		return bal*irate+(0.02*bal);
		else {
		return	bal*irate;
		}
	}
	
	public void withdraw(int amt) {
	double bal=this.getBalance();
	if(bal>minbal) {
	this.withdraw(amt);
	}
	else {
		System.out.println("insufficient bal");
	}
}
	public void deposit(int amt) {
		this.deposit(amt);
	}
	
	//overridden toString	
	public String toString() {
		return super.toString() ;}
	
	}


