package com.demo.bean;

public class Current extends Account {
	private double irate=0.03;
	private int numt=3;
	//default constructor
	public Current() {
		super();
	}
	//parametrized constructor
	public Current(String name,int pin,double bal) 
	{ super(name,pin,bal);
		
	}
	//getter and setter
public int getNumt() {
		return numt;
	}
	public void setNumt(int numt) {
		this.numt = numt;
	}
	//interest 
public double interest() {
	double bal=getBalance();
	return	bal*irate;
	}


public void withdraw(int amt) {
		this.withdraw(amt);
	}
public void deposit(int amt) {
	this.deposit(amt);
}
	
//overridden toString	
	public String toString() {
		return super.toString() ;}
	
	
}