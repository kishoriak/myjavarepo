package com.demo.bean;
import java.util.Date;
import java.text.SimpleDateFormat;
abstract public class Account {
	private static int cnt=1;//for maintaining id
	private int id;
	private String name;
    protected int pin;
	private double balance;
	private Date d;
	
	//Default Constructor
	public Account() {
		id=0;
		name=null;
	    pin=0;
		balance=0;
		d=null;
	}
	//date
	SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
	Date date = new Date();
	
	//parametrised constructor
	public Account(String name,int pin,double bal) {
	this.id=cnt;
	cnt++;
	this.name=name;
	this.pin=pin;
	this.balance=bal;
	d=date;
	}
	
  //getters and setters
	public int getid() {
    	return this.id;
    }
    public void name(String name) {
    	this.name=name;
    }
    public String getname() {
    	return this.name;
    }
    	
    	public void setPin(int pin) {
    		this.pin=pin;
    	
    }
    	public int getPin() {
    		return this.pin;
    	}
    public void setBalanceDep(double balance) {
    	this.balance+=balance;
    }
   
    public double getBalance() {
    	return this.balance;
    }
    //withdraw function
    public void withdraw(double amt) {
    	this.balance-=amt;
    	
   }
    //deposit function
    public void deposit(double amt) {
    	this.balance+=amt;
    }
    
    //display function override
    @Override
public String toString() {
return "pId:"+id+"\nName"+name+"\nbalance"+balance+"\n Date"+d;
}
  
  //verify pin
  public boolean verifyPin(int pin) {
 		
 		if(this.getPin()==pin) {
 			return true;
 		}
 		else {
 			return false;
 		}
 		
 	}

public abstract double interest();
}

