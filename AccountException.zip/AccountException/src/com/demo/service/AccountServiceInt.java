package com.demo.service;

import com.bean.dao.UserNotFound;
import com.demo.bean.Account;
import com.demo.exception.WrongPin;

public interface AccountServiceInt {
	public Account Display(int id) throws UserNotFound ;
	public  void deposit(int id,double dep);
	public void withdraw(int id,double amt,int pin) throws WrongPin;
	public double interest(int id);
	public  int searchById(int id) throws UserNotFound;
}
