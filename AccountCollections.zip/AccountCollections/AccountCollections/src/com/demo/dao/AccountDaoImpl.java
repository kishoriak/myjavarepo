package com.demo.dao;



import java.util.HashSet;
import java.util.Set;

import com.demo.bean.*;
import com.demo.exception.AccountNotFoundException;
import com.demo.exception.InvalidAmountException;

public  class AccountDaoImpl implements AccountDao {
	static Set<Account> pset;
	static {
		pset=new HashSet<>();
	}
	//add account
	@Override
	public void addAccount(Account account) {
		System.out.println("in Dao add");
		 pset.add(account);
		
		
	}
	
	//Search account by id
	@Override
	public Account searchById(int id) throws AccountNotFoundException  {

		for(Account acc:pset) {
			if(acc.getAccId()==id) {
				return acc;
			}
		}
		throw new AccountNotFoundException("Account with id : " + id + " not Found!");
	}

	//Deposite Amount 
	@Override
	public int depositAmt(Account acc, double amount) throws InvalidAmountException {
			acc.deposite(amount);
			return 1;
			
	}
	
	//Withdraw Amount
	@Override
	public int withdrawAmt(Account acc, double amount, int pin) {
		 acc.withdraw(amount);
		return 1;
		
	}
	
	
	//Display balance
	@Override
	public double displayBalance(Account acc,int id) {
		
			return acc.getAccbalance();
			
			
	}

	//change pin
	@Override
	public int changePin(Account acc, int pin, int pin1) {
		// TODO Auto-generated method stub
		 acc.setPin(pin1);
		return 1;
		
		
	}

	//Transfer Account
	@Override
	public void transferAmount(Account targetAcc, double amount) {
		targetAcc.setAccBalance(targetAcc.getAccbalance() + amount);
	}
	
    
		
    
	
	}
