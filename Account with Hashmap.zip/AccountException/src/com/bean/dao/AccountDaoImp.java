package com.bean.dao;


import java.awt.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.demo.bean.Account;
import com.demo.bean.Current;
import com.demo.bean.Savings;
import com.demo.exception.WrongPin;

public class AccountDaoImp  implements AccountDao {
//static members
	public static Map<Integer,Account> map;
	public static int cnt;
	static {
		map=new HashMap<>();
		cnt=0;
		}		
	//accepting data
	public void AcceptDataSavings(String name,int pin,double bal,int cbnum) {
		Account e=new Savings(name,pin,bal,cbnum);
		map.put(e.getCount(),e );
		cnt++;
	}
	public void AcceptDataCurrent(String name,int pin,double bal) {
		Account a=new Current(name,pin,bal);
		map.put(a.getCount(),a);
		cnt++;
	}
	
	
	public void deposit(int id,double dep) {
		Account a=map.get(id);
		a.withdraw(dep);
	}
	public Account display(int id) throws UserNotFound {
		Account a=map.get(id);
		if(a!=null) {
		return a ;
	}
		else {
			throw new UserNotFound("UserNotFound");
		}
	}
	//interest
	public double interest(int id) {
		Account a=map.get(id);
		return a.interest();
	}

//withdraw
public void withdraw(int id,double amt,int pin) throws WrongPin{
	Account a= map.get(id);
	boolean check=a.verifyPin(pin);
	if(check==true) {
	a.withdraw(amt);
	}
	else {
		throw new WrongPin("Wrong Pin");
	}
	
}
}
	  
	
	


