package com.demo.service;
import java.text.SimpleDateFormat;
import java.util.Scanner;
import com.bean.dao.AccountDaoImp;
import com.bean.dao.UserNotFound;
import com.demo.bean.Account;
import com.demo.exception.WrongPin;

public class AccountServiceImp implements AccountService {
public static SimpleDateFormat 
sdf=new SimpleDateFormat("dd/MM/yyyy");//date
	public static Scanner sc=new Scanner(System.in);
	private AccountDaoImp dao=new AccountDaoImp();
	//accept data from the user for account
	public  void acceptData(int n){
	
	System.out.println("Enter name:");
	String name=sc.next();
	System.out.println("Enter balance:");
	double bal=sc.nextDouble();
	System.out.println("Enter pin:");
	int pin=sc.nextInt();
	if(n==1) {
	System.out.println("Enter check book no.:");
	int cbnum=sc.nextInt();
	dao.AcceptDataSavings(name,pin,bal,cbnum);
	}
	else {
	dao.AcceptDataCurrent(name, pin, bal);	
	     }
	}
	
	//to display
public Account Display(int id) throws UserNotFound {
	Account a=dao.display(id);
          return a;      }

//to deposit
public  void deposit(int id,double dep) {
	dao.deposit(id,dep);
		}   

//to withdraw
public void withdraw(int id,double amt,int pin) throws WrongPin {
	dao.withdraw(id,amt,pin);
        }

//interest
public double interest(int id) {
	return dao.interest(id);
        }

//search by id
public  int searchById(int id) throws UserNotFound {
return dao.searchById(id);
        }
}
