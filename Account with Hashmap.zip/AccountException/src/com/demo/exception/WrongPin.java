package com.demo.exception;

public class WrongPin extends Exception{
	public WrongPin(String mesg) {
		super(mesg);
	}

}
