package com.demo.test;
import java.util.Scanner;
import com.bean.dao.UserNotFound;
import com.demo.bean.Account;
import com.demo.exception.WrongPin;
import com.demo.service.AccountServiceImp;
public class TestAccount {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		AccountServiceImp accountService=new AccountServiceImp();
		// data for account
	    boolean y=true;
		//start of first screen
		while(y) {
		System.out.println("Choose one option:\n 1 Create Savings Account \n 2 Create Current Account \n "+
				"3 Deposit  \n 4 Withdraw \n 5 Display \n 6 Interest \n 7 Exit");
		int n=sc.nextInt();  //option in
	
		switch(n) {
		case(1):                         //savings
			accountService.acceptData(n);//passing count and n for reference
		break;
		    
		case(2):                         //current
	     accountService.acceptData(n);
		break;
        
        case(3):                         //deposit
        	System.out.println("Enter the id:");
			int did=sc.nextInt();
			System.out.println("Enter the amount:");
			double dep=sc.nextDouble();
		    accountService.deposit(did,dep); 
		    break;
		
		                                                 //withdraw
		case(4):for(int i=0;i<3;i++) {        
			try{                                         //try block
		System.out.println("Enter the id:");
		int wid=sc.nextInt();
	     System.out.println("Enter the pin:");
		int pin=sc.nextInt();
		System.out.println("Enter the amount:");
		double draw=sc.nextDouble();
		accountService.withdraw(wid,draw,pin);
		break;}
			catch(WrongPin e) {
				System.out.println(e.getMessage());
			}
		}
		break;
        
		case(5)://display
			try {
		System.out.println("Enter the id:");
		int id=sc.nextInt();
		Account a=accountService.Display(id);
		System.out.println(a);}
		catch(UserNotFound e) {
			System.out.println(e.getMessage());
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		break;
		
		case(6):                           //check interest
	    System.out.println("Enter the id:");
		int nid=sc.nextInt();
		double i=accountService.interest(nid);
		System.out.println("Interest:"+i);
		break;
		
		case(7):                            //Exit
		System.exit(0);
		break;
		}//while
       }
		sc.close();
		}
		
	}
  


