//main class used to chechk working only
package com.demo.test;
import java.util.Scanner;
import java.util.Set;

import com.demo.Exception.NegativePriceException;
import com.demo.bean.Apparel;
import com.demo.bean.Electronics;
import com.demo.bean.Food;


public class Test {
public static void main(String[]args){
ItemService itemService=new ItemService();
//to add food item press 1
//itemService.addFitem();
//to add Electronics item press 2
//itemService.addEitem();
//to add Apparels item press 3
itemService.addAitem();



}
}
