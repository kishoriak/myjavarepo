package com.demo.dao;

import java.util.Set;

import com.demo.bean.Apparel;
import com.demo.bean.Electronics;
import com.demo.bean.Food;
import com.demo.bean.Item;

public interface ItemDao {
	
	boolean addFitem(Food f);
	public boolean addAitem(Apparel a);
	public boolean addeItem(Electronics e) ;
	
}
