package com.demo.dao;

import java.util.HashSet;
import java.util.Set;

import com.demo.bean.Apparel;
import com.demo.bean.Electronics;
import com.demo.bean.Food;
import com.demo.bean.Item;

public class ItemDaoImpl implements ItemDao{
	//hashset for food
	static Set<Food> fset;
	static {
		fset=new HashSet<>();
	}
	//hashset for apparels
	static Set<Apparel> aset;
	static {
		aset=new HashSet<>();
	}
	//hashset for electronics
	static Set<Electronics> eset;
	static {
		eset=new HashSet<>();
	}
	//Add functions for various items
	@Override
	public boolean addFitem(Food f) {
		return fset.add(f);
		
		}
	public boolean addFitem(Apparel a) {
		return aset.add(a);
		
		}
	public boolean addEitem(Electronics e) {
		return eset.add(e);
		
		//Display functions for various items
		}
	public Set<Food> displayFitems(){
		return fset;
	}
	public Set<Apparel> displayAitems(){
		return aset;
	}
	public Set<Electronics> displayEitems(){
		return eset;
	}



}
