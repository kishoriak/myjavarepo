//Author:Dharampreet singh
//this class is business logic and interacts with gui and accepts data

package com.demo.service;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Scanner;
import java.util.Set;

import com.demo.Exception.NegativePriceException;
import com.demo.bean.Apparel;
import com.demo.bean.Electronics;
import com.demo.bean.Food;
import com.demo.dao.ItemDaoImpl;

public class ItemServiceImpl implements ItemService {
	
ItemDaoImpl idao=new ItemDaoImpl();
Scanner sc=new Scanner(System.in);
SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
//Add food item if 1 is called on main function
public boolean addFitem() {
	int i;
	//provide 3 chacnes for price
	for(i=0;i<3;i++) {
	System.out.println("Enter item code:");
	int code=sc.nextInt();
	System.out.println("Enter item name:");
	String name=sc.next();
	System.out.println("Enter  quantity sold:");
	int qty=sc.nextInt();
	// chechk negative price 
	try {   
	System.out.println("Enter  price:");
	int price=sc.nextInt();
	System.out.println("Enter veg type:");
	String veg=sc.next();
	System.out.println("Enter date of expiry:");
	String dt1=sc.next();
	if(price<0) {
		throw new NegativePriceException("Enter positive price");
	}
	Date doe=(Date) sdf.parse(dt1);
	System.out.println("Enter date of manufacture");
	String dt2=sc.next();
	Date dom=(Date) sdf.parse(dt2);
	Food f=new Food(code,name,qty,price,doe,dom);
	return idao.addFitem(f);
}
	catch(NegativePriceException e) {
		System.out.println(e.getMessage());
	}
	if(i==2) {
		return false;
	}
	}
}
	
//Add Apparel item if 2 is called on main function
public boolean addAItem() {
	int i;
	//provide 3 chacnes for price
	for(i=0;i<3;i++) {
	System.out.println("Enter item code:");
	int code=sc.nextInt();
	System.out.println("Enter item name:");
	String name=sc.next();
	System.out.println("Enter  quantity sold:");
	int qty=sc.nextInt();
	// chechk negative price 
	try {
	System.out.println("Enter  price:");
	int price=sc.nextInt();
	System.out.println("Enter size:");
	String size=sc.next();
	System.out.println("Enter material");
    String mat=sc.next();
    if(price<0) {
    	throw new NegativePriceException("Enter positive price");
    }
    Apparel a=new Apparel(code,name,qty,price,size,mat);
    return idao.addAitem(a);
}
	catch(NegativePriceException e) {
		System.out.println(e.getMessage());
	}
	if(i==2) {
		return false;
	}
	}
}
//Add electronic item if 3 is called on main function
public boolean addEitem() {
	int i;
	//provide 3 chacnes for price
	for(i=0;i<3;i++) {
	System.out.println("Enter item code:");
	int code=sc.nextInt();
	System.out.println("Enter item name:");
	String name=sc.next();
	System.out.println("Enter  quantity sold:");
	int qty=sc.nextInt();
	// chechk negative price 
	try {
	System.out.println("Enter  price:");
	int price=sc.nextInt();
	System.out.println("Enter warranty");
	int warr=sc.nextInt();
	if(price<0) {
		throw new NegativePriceException("Enter positive price");
	}
	Electronics e=new Electronics(code,name,qty,price,warr);
	return idao.addeItem(e);
}
catch(NegativePriceException e){
	System.out.println(e.getMessage());
}
	}
	if(i==2) {
		return false;
	}
	
}
//display functions for various items
public Set<Food> displayFitems(){
	return idao.displayFitems();
}
public Set<Apparel> displayAitems(){
	return idao.displayAitems();
}
public Set<Electronics> displayEitems(){
	return idao.displayEitems();
}


}
