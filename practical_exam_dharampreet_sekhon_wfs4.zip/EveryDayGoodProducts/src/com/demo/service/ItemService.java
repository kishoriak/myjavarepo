package com.demo.service;

public interface ItemService {

}
