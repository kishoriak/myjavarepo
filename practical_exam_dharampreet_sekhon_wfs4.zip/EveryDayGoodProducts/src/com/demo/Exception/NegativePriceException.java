package com.demo.Exception;

public class NegativePriceException {

}
