package com.demo.bean;

import java.sql.Date;

public class Food extends Item{
	private String veg;
	private Date dom;
	private Date doe;
	

	public Food() {
		super();
	}


	public Food(int icode, String name, int qsold,String veg,Date dom,Date doe) {
		super(icode, name,qsold);
		this.veg = veg;
		this.dom=dom;
		this.doe=doe;
	}
	

}
