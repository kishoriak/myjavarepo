package com.demo.bean;

public class Electronics extends Item{
	private int warr;
	
	

    public Electronics() {
		super();
	}


	public Electronics(int icode, String name, int qsold,int warr) {
		super(icode,name,qsold);
		this.warr = warr;
		
	}

}
