package com.demo.bean;

public class Apparel extends Item {
	private String size;
	private String mat;
	
	public Apparel() {
		super();
	}

	public Apparel(int icode, String name, int qsold,String size, String mat) {
		super(icode,name,qsold);
		this.size = size;
		this.mat = mat;
	}
	

}
