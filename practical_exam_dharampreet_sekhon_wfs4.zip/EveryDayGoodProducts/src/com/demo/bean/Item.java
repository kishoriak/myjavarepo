package com.demo.bean;

public class Item {
private int icode;
private String name;
private int qsold;
public Item() {
	super();
}
public Item(int icode, String name, int qsold) {
	super();
	this.icode = icode;
	this.name = name;
	this.qsold = qsold;
}
public int getIcode() {
	return icode;
}
public void setIcode(int icode) {
	this.icode = icode;
}
public int getQsold() {
	return qsold;
}
public void setQsold(int qsold) {
	this.qsold = qsold;
}
@Override
public String toString() {
	return "Product [icode=" + icode + ", name=" + name + ", qsold=" + qsold + "]";
}


}
