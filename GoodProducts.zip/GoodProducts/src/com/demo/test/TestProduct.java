package com.demo.test;

import java.util.Scanner;

import com.demo.service.ProductService;
import com.demo.service.ProductServiceImpl;



public class TestProduct {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Object Creation of Product ServiceImpl class
		ProductService productService=new ProductServiceImpl();
		Scanner sc = new Scanner(System.in);
		int choice = 0;
		
		
		
		//Menu to be displayed
		do {
			System.out.println("1. Add new Product");	
			System.out.println("2. Display account by Id");
			System.out.println("3. Exit");
			
			choice = sc.nextInt();
			int id = 0;
			double amount = 0;
			int productType = 0;
			
			switch(choice) {
				case 1:
					System.out.println("Enter Type Of Product");
					System.out.println("1. Food Items");
					System.out.println("2. Apparel");
					System.out.println("3. Electronics");
					productType = sc.nextInt();
					productService.acceptProductData(productType);
					System.out.println("Account created");
					
					break;
				
				case 2:
					System.out.println("Enter Type Of Product");
					System.out.println("1. Food Items");
					System.out.println("2. Apparel");
					System.out.println("3. Electronics");
					productType = sc.nextInt();
					productService.displayProductData(productType);
					break;
				case 3:
					System.exit(0);
			}
		}while(choice != 3);
	}

	}

}
