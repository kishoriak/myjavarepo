package com.demo.bean;


//Electronics is child class of Product class
public class Electronics extends Product {
    
	//variable Declaration
	private int warranty;

	//Default Constructor
	public Electronics() {
		super();
	}
	
	//Parameterized Constructor
	public Electronics(int itemCode, String itemName, double unitPrice,int quantity,int warranty) {
		super(itemCode,itemName,unitPrice,quantity);
		this.warranty = warranty;
	}

	//Setter and Getter Methods
	public int getWarranty() {
		return warranty;
	}

	public void setWarranty(int warranty) {
		this.warranty = warranty;
	}

	
	//Override toString method of object class to display
	@Override
	public String toString() {
		return super.toString()+"Electronics [warranty=" + warranty + "]";
	}

	
	
	
	
	
}
