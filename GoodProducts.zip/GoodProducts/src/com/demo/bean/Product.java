package com.demo.bean;


//Product Class As Base Class 
public class Product {
	
	//Variable Declaration
	private int itemCode;
	private String itemName;
	private double unitPrice;
	private int quantity;
	
	//Default Constructor
	public Product() {
		super();
	}

	//Parameterized Constructor
	public Product(int itemCode, String itemName, double unitPrice,int quantity) {
		super();
		this.itemCode = itemCode;
		this.itemName = itemName;
		this.unitPrice = unitPrice;
		this.quantity=quantity;
		
	}

	//Setter and Getter Methods
	public int getItemCode() {
		return itemCode;
	}

	public void setItemCode(int itemCode) {
		itemCode = itemCode;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		itemName = itemName;
	}

	public double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(double unitPrice) {
		unitPrice = unitPrice;
	}
	
	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		quantity = quantity;
	}

	//Equals method 
	@Override
	public boolean equals(Object obj) {
		if(this.itemCode==((Product)obj).itemCode) {
			return true;
		}
		return false;
	}
	//Override toString method of Object class to display
	@Override
	public String toString() {
		return "Product [ItemCode=" + itemCode + ", ItemName=" + itemName + "Quantity="+ quantity+ "]";
	}
	
	
	
	
	
	

}
