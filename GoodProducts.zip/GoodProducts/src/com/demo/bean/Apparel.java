package com.demo.bean;


//Apparel class is child class of product
public class Apparel extends Product{
	
	//Variable Declaration
	private String size;
	private String materialType;
	
	//Default constructor
	public Apparel() {
		super();
	}

	//Parameterized Constructor
	public Apparel(int itemCode, String itemName, double unitPrice,int quantity,String size, String materialType) {
		super(itemCode,itemName,unitPrice,quantity);
		this.size = size;
		this.materialType = materialType;
	}

	
	//Override toString method of object class to display
	@Override
	public String toString() {
		return super.toString()+"Apparel [size=" + size + ", materialType=" + materialType + "]";
	}
	
	
	
	
	
	

}
