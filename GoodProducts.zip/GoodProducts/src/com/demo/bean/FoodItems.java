package com.demo.bean;

import java.util.Date;

//FoodItem class as a child class of Product class 
public class FoodItems extends Product {
	
	//Variable Declaration
	private Date dateOfManufacture;
	private Date dateOfExpiry;
	private String vegType;
	
	//Default Constructor
	public FoodItems() {
		super();
	}

	//Parameterized Constructor
	public FoodItems(int itemCode, String itemName, double unitPrice,int quantity,String vegType) {
		super(itemCode,itemName,unitPrice,quantity);
		this.dateOfManufacture = dateOfManufacture;
		this.dateOfExpiry = dateOfExpiry;
		this.vegType=vegType;
		
	}
	
	
    //Setter and Getter Methods
	public Date getDateOfManufacture() {
		return dateOfManufacture;
	}

	public void setDateOfManufacture(Date dateOfManufacture) {
		this.dateOfManufacture = dateOfManufacture;
	}

	public Date getDateOfExpiry() {
		return dateOfExpiry;
	}

	public void setDateOfExpiry(Date dateOfExpiry) {
		this.dateOfExpiry = dateOfExpiry;
	}
 
	public String getVegType() {
		return vegType;
	}

	public void setVegType(String vegType) {
		this.vegType = vegType;
	}
	
	//Override toString method of object class to display
	@Override
	public String toString() {
		return super.toString()+"FoodItems [VegType=" + vegType + "]"; 
				
	}
	
	
	
	
	

}
