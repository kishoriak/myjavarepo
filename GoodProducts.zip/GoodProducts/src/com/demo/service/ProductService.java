package com.demo.service;

import com.demo.bean.Product;
import com.demo.exception.QuantityNotValidException;
import com.demo.exception.TypeNotFound;

public interface ProductService {

	Product acceptProductData(int accountType) throws QuantityNotValidException, TypeNotFound;

	void displayProductData(int productType);

}
