package com.demo.service;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Scanner;

import com.demo.bean.Apparel;
import com.demo.bean.Electronics;
import com.demo.bean.FoodItems;
import com.demo.bean.Product;
import com.demo.dao.ProductDao;
import com.demo.dao.ProductDaoImpl;
import com.demo.exception.QuantityNotValidException;
import com.demo.exception.TypeNotFound;

public class ProductServiceImpl implements ProductService {

	
	public static SimpleDateFormat sdf=new SimpleDateFormat("dd/mm/yyyy");
	public static Scanner sc =new Scanner(System.in);
	private  ProductDao productDao;
	
	//Default constructor
	public ProductServiceImpl(){
			this.productDao = new ProductDaoImpl();
		}

	
	//Add product data
	@Override
	public Product acceptProductData(int productType) throws QuantityNotValidException, TypeNotFound {
		// TODO Auto-generated method stub
		Product pro=null;
		System.out.println("Enter Item Code :");
		int itemCode = sc.nextInt();
		System.out.println("Enter Item Name :");
		String itemName = sc.next();
		System.out.println("Enter Item Price :");
		int itemPrice = sc.nextInt();
	
		System.out.println("Enter Qunatity :");
		int qty= sc.nextInt();
		if(qty<0)
		{
			throw new QuantityNotValidException("Enter Valid Quantity");
		}
			
			if(productType == 1) {
				
				System.out.println("Enter Type Of Veg :");
				String vegType = sc.next();
				
				pro = new FoodItems( itemCode, itemName,itemPrice, qty,vegType);
			}
			else if(productType == 2) {
				System.out.println("Enter Size:");
				String size = sc.next();
				System.out.println("Enter Type Of Material :");
				String material = sc.next();
				pro = new Apparel(itemCode, itemName,itemPrice, qty,size,material);
			}
			else if(productType==3)
			{
				System.out.println("Enter Warranty:");
				int warranty = sc.nextInt();
				pro=new Electronics(itemCode, itemName,itemPrice, qty,warranty);
				
			}
			else
			{
				throw new TypeNotFound("Enter valid Type");
			}
			 productDao.addAccount(pro);
		
		return pro;

		
		
	}

    //display
	@Override
	public void displayProductData(int productType) {
		// TODO Auto-generated method stub
		
		productDao.displayProductData(productType);
	}
    
	@Override
	//sort on quantity
	public List<Product> sortOnQuantity() {
		return productDao.sortData();
	}
	
}
