package com.demo.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.demo.bean.Product;
import com.demo.comparator.MyQuantityComparator;
import com.demo.exception.ProductNotFoundException;

public class ProductDaoImpl implements ProductDao {

	
	//Array list 
	static ArrayList<Product> arrayList;
    static {
   	 arrayList=new ArrayList<>();
    }
	private int productType=0;
	//Adding Product to Array List
	@Override
	public void addAccount(Product pro) {
		// TODO Auto-generated method stub
		arrayList.add(pro);
	}

	
	public Product searchById(int id)  {
		// TODO Auto-generated method stub
		
		//indexOf
	   	Product e=null;
		
	    e=new Product(id,null,0.0,0);

		int pos=arrayList.indexOf(e);
		if(pos!=-1)
		{
			return arrayList.get(pos);
		}
		throw new ProductNotFoundException("Product with id "+id+" Not Found");
		
		
	//Display Product Data

	@Override
	public void displayProductData(int productType) {
		// TODO Auto-generated method stub
	     
	}


	@Override
	public List<Product> sortData() {
		// TODO Auto-generated method stub
		Collections.sort(arrayList, new MyQuantityComparator());
		return arrayList;
	}

}
