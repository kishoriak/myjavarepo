package com.demo.exception;

public class QuantityNotValidException extends Exception {
   
	public QuantityNotValidException(String msg)
	{
		super(msg);
	}
}
