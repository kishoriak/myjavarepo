package com.demo.exception;

public class TypeNotFound extends Exception {
    
	public TypeNotFound(String msg)
	{
		super(msg);
	}
}
